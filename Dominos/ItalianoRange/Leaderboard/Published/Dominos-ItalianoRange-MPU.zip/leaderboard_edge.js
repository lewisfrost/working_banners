
(function(compId){var _=null,y=true,n=false,x28='break-word',x86='35px',x1='5.0.1',x50='rgb(0, 0, 0)',x88='65px',e61='${TextCopy}',e95='${dots}',cl='clip',x103='12px',x85='32px',x53='-2px',x65='238px',x51='rgba(255,0,0,1.00)',x93='144px',i='none',x82='rect(@@0@@px @@1@@px @@2@@px @@3@@px)',x105='341px',x8='rgba(255,255,255,1)',xc='rgba(0,0,0,1)',x54='300px',x34='nowrap',x2='5.0.0',e60='${close_click}',zx='scaleX',x55='open_click',x47='30px',x49='0',x42='10px',x106='20px',x78='rect(0px 0px 16px 0px)',e81='${frame2-txt1}',e14='${copy}',x3='5.0.1.386',p='px',o='opacity',e13='${logoCopy}',x27='rgba(0,0,0,1.00)',x104='399px',x96='106px',x41='ClosedBgCopy',e62='${ClosedBgCopy}',x73='frame2-txt2',x77='frame2-txt1',e111='${try}',e9='${Symbol_3Copy4}',x24='125px',e12='${bg2}',x101='109px',e83='${frame2-txt2}',x43='475px',x21='rgba(255,255,255,0.66)',x37='57',e10='${new}',x66='71px',x35='Text2',x98='343px',x94='143px',x38='17',x25='16px',x18='26px',x87='66px',x91='76px',bg='background-color',x84='try',e59='${ClosedBg}',x22='-1px',x67='frame2-lines',x74='rect(0px 235px 17px 232px)',x31='200',zy='scaleY',x72='17px',x4='rgba(0,0,0,0)',x70='37px',x57='27px',g='image',po='center',x48='close_click',x69='5px',x23='8px',x97='19px',x52='2px',x='text',x64='4px',x76='3px',m='rect',x15='0px',x16='1px',e63='${open_click}',x39='Text3',e107='${openBg}',x90='dots',b='block',x20='ClosedBg',e11='${logo}',x32='90',x40='378px',lf='left',d='display',x100='11px',x99='openBg',x26='Arial, Helvetica, sans-serif',l='normal',rz='rotateZ',x17='126px',x108='0.8',x29='Text',x19='auto',w='width',e58='${Text}',tp='top',x33='400',x46='167px',x80='242px',x71='235px',x44='TextCopy',x56='162px';var g109='try.png',g110='dots.png',g92='dots2.png',g79='frame2-txt1.png',g5='bg.jpg',g113='dots3.png',g112='try3.png',g7='logo.png',g68='frame2-lines.png',g75='frame2-txt2.png',g6='new.png',g89='try2.png';var s102="<p style=\"margin: 0px;\">​Terms &amp; conditions <span style=\"font-size: 11px;\"></span></p>",s30="<p style=\"margin: 0px;\">​Terms and conditions <span style=\"font-size: 11px;\"></span></p>",s36="<p style=\"margin: 0px;\">​</p>",s45="<p style=\"margin: 0px;\">Participating stores. Subject to availability. T&amp;C apply, see dominos.co.uk​</p>";var im='',aud='',vid='',js='',fonts={},opts={'gAudioPreloadPreference':'auto','gVideoPreloadPreference':'auto'},resources=[],scripts=[],symbols={"stage":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{id:'bg2',t:g,r:['0px','0px','728px','90px','auto','auto'],f:[x4,im+g5,'0px','0px']},{id:'copy',symbolName:'Symbol_1',t:m,r:['247px','9px','242','71','auto','auto'],o:'0'},{id:'new',t:g,r:['31px','8px','67px','47px','auto','auto'],f:[x4,im+g6,'0px','0px']},{id:'logo',t:g,r:['240px','-27px','245px','147px','auto','auto'],f:[x4,im+g7,'0px','0px']},{id:'logoCopy',t:g,r:['240px','-26px','245px','147px','auto','auto'],f:[x4,im+g7,'0px','0px']},{id:'tandc',symbolName:'tandc_1',t:m,r:['0px','63px','162','27','auto','auto']},{id:'Symbol_3Copy4',symbolName:'Symbol_3_2',v:i,t:m,r:['598px','-24px','144','143','auto','auto'],o:'0',tf:[[],[],[],['1.29','1.29']]}],style:{'${Stage}':{isStage:true,r:['null','null','728px','90px','auto','auto'],overflow:'hidden',f:[x8]}}},tt:{d:10042,a:y,data:[["eid148",zx,8045,303,"linear",e9,'1.29','1'],["eid73",o,403,579,"linear",e10,'0','1'],["eid74",o,2733,250,"linear",e10,'1','0'],["eid62",lf,0,892,"easeOutQuad",e11,'5px','243px'],["eid32",zx,78,788,"swing",e12,'1.4','1'],["eid72",zx,404,579,"linear",e10,'1.29','1'],["eid147",zy,8045,303,"linear",e9,'1.29','1'],["eid82",d,7000,0,"easeOutQuad",e13,i,b],["eid93",o,3500,500,"easeOutQuad",e14,'0','1'],["eid94",o,6462,500,"easeOutQuad",e14,'1','0'],["eid146",o,8045,303,"linear",e9,'0','1'],["eid33",zy,78,788,"swing",e12,'1.4','1'],["eid84",lf,7000,1045,"swing",e13,'533px','240px'],["eid145",d,8045,0,"linear",e9,i,b],["eid63",o,78,814,"easeOutQuad",e11,'0','1'],["eid64",o,2750,250,"easeOutQuad",e11,'1','0'],["eid83",o,7061,500,"linear",e13,'0','1'],["eid75",zy,404,579,"linear",e10,'1.29','1'],["eid29","tr",0,function(e,d){this.eSA(e,d);},['stop','${copy}',[]]],["eid130","tr",0,function(e,d){this.eSA(e,d);},['stop','${tandc}',[]]],["eid149","tr",0,function(e,d){this.eSA(e,d);},['stop','${Symbol_3Copy4}',[]]],["eid98","tr",3250,function(e,d){this.eSA(e,d);},['play','${copy}',[]]],["eid99","tr",6000,function(e,d){this.eSA(e,d);},['playReverse','${copy}',[]]],["eid150","tr",8045,function(e,d){this.eSA(e,d);},['play','${Symbol_3Copy4}',[]]]]}},"tandc":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{t:m,r:[x15,x16,x17,x18,x19,x19],id:x20,s:[0,xc,i],v:b,f:[x21]},{r:[x22,x23,x24,x25,x19,x19],n:[x26,[11,p],x27,l,i,'',x28,l],v:b,id:x29,text:s30,align:po,t:x},{r:[x31,x32,x19,x19,x19,x19],n:[x26,[24,p],xc,x33,i,l,x28,x34],align:lf,id:x35,text:s36,ts:['','','','',i],t:x},{r:[x37,x38,x19,x19,x19,x19],n:[x26,[12,p],x8,x33,i,l,x28,x34],align:lf,id:x39,text:s36,ts:['','','','',i],t:x},{t:m,r:[x15,x16,x40,x18,x19,x19],id:x41,s:[0,xc,i],v:i,f:[x21]},{r:[x42,x23,x43,x25,x19,x19],n:[x26,[11,p],x27,l,i,'',x28,l],id:x44,text:s45,v:i,t:x},{t:m,r:[x15,x22,x46,x47,x19,x19],v:b,id:x48,o:x49,s:[0,x50,i],f:[x51]},{t:m,r:[x52,x53,x54,x47,x19,x19],v:i,id:x55,o:x49,s:[0,x50,i],f:[x51]}],style:{'${symbolSelector}':{r:[_,_,x56,x57]}}},tt:{d:14794,a:y,l:{"closed":0,"open":1450},data:[["eid321",d,1297,0,"linear",e58,b,i],["eid319",d,1297,0,"linear",e59,b,i],["eid345",d,1461,0,"linear",e60,b,i],["eid124",tp,14794,0,"linear",e61,'8px','8px'],["eid126",d,1450,0,"linear",e62,i,b],["eid123",w,14794,0,"linear",e61,'475px','475px'],["eid341",d,1450,0,"linear",e63,i,b],["eid122",d,1450,0,"linear",e61,i,b]]}},"Symbol_1":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x64,x15,x65,x66,x19,x19],id:x67,t:g,f:[x4,im+g68,x15,x15]},{r:[x69,x70,x71,x72,x19,x19],id:x73,t:g,cl:x74,f:[x4,im+g75,x15,x15]},{r:[x76,x72,x71,x25,x19,x19],id:x77,t:g,cl:x78,f:[x4,im+g79,x15,x15]}],style:{'${symbolSelector}':{r:[_,_,x80,x66]}}},tt:{d:1250,a:y,data:[["eid138",cl,500,750,"easeOutQuad",e81,[0,0,16,0],[0,235,16,0],{vt:x82}],["eid134",cl,500,750,"easeOutQuad",e83,[0,235,17,232],[0,235,17,0],{vt:x82}]]}},"Symbol_3":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{id:x84,t:g,r:[x85,x86,x87,x88,x19,x19],f:[x4,im+g89,x15,x15]},{id:x90,t:g,r:[x57,x47,x91,x91,x19,x19],f:[x4,im+g92,x15,x15]}],style:{'${symbolSelector}':{r:[_,_,x93,x94]}}},tt:{d:7000,a:y,data:[["eid231",rz,0,7000,"linear",e95,'0deg','360deg']]}},"tandc_1":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{t:m,r:[x15,x23,x96,x97,x19,x19],id:x20,s:[0,xc,i],v:b,f:[x21]},{t:m,r:[x15,x23,x98,x97,x19,x19],id:x99,s:[0,xc,i],v:i,f:[x21]},{r:[x53,x100,x101,x25,x19,x19],n:[x26,[10,p],x27,l,i,'',x28,l],v:b,id:x29,text:s102,align:po,t:x},{r:[x23,x103,x104,x25,x19,x19],n:[x26,[10,p],x27,l,i,'',x28,l],id:x44,text:s45,v:i,t:x},{r:[x31,x32,x19,x19,x19,x19],n:[x26,[24,p],xc,x33,i,l,x28,x34],align:lf,id:x35,text:s36,ts:['','','','',i],t:x},{t:m,r:[x15,x22,x46,x47,x19,x19],v:b,id:x48,o:x49,s:[0,x50,i],f:[x51]},{t:m,r:[x52,x23,x105,x106,x19,x19],v:i,id:x55,o:x49,s:[0,x50,i],f:[x51]},{r:[x37,x38,x19,x19,x19,x19],n:[x26,[12,p],x8,x33,i,l,x28,x34],align:lf,id:x39,text:s36,ts:['','','','',i],t:x}],style:{'${symbolSelector}':{r:[_,_,x56,x57]}}},tt:{d:12982,a:y,l:{"closed":0,"open":1450},data:[["eid382",bg,618,0,"linear",e59,'rgba(255,255,255,0.66)','rgba(255,255,255,0.66)'],["eid321",d,1297,0,"linear",e58,b,i],["eid345",d,1461,0,"linear",e60,b,i],["eid365",tp,12982,0,"linear",e61,'12px','12px'],["eid324",d,1450,0,"linear",e107,i,b],["eid319",d,1297,0,"linear",e59,b,i],["eid341",d,1450,0,"linear",e63,i,b],["eid323",d,1450,0,"linear",e61,i,b]]}},"Symbol_3_1":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x85,x86,x87,x88,x19,x19],id:x84,tf:[[],[],[],[x108,x108]],t:g,f:[x4,im+g109,x15,x15]},{r:[x57,x47,x91,x91,x19,x19],id:x90,tf:[[],[],[],[x108,x108]],t:g,f:[x4,im+g110,x15,x15]}],style:{'${symbolSelector}':{r:[_,_,x93,x94]}}},tt:{d:1137,a:y,data:[["eid439",zx,0,500,"linear",e111,'1','0.8'],["eid461",zx,500,500,"linear",e111,'0.8','1'],["eid435",zx,0,500,"linear",e95,'1','0.8'],["eid459",zx,500,500,"linear",e95,'0.8','1'],["eid436",zy,0,500,"linear",e95,'1','0.8'],["eid460",zy,500,500,"linear",e95,'0.8','1'],["eid441",zy,0,500,"linear",e111,'1','0.8'],["eid462",zy,500,500,"linear",e111,'0.8','1']]}},"Symbol_3_2":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{tf:[[],[],[],[x108,x108]],id:x84,t:g,r:[x85,x86,x87,x88,x19,x19],f:[x4,im+g112,x15,x15]},{tf:[[],[],[],[x108,x108]],id:x90,t:g,r:[x57,x47,x91,x91,x19,x19],f:[x4,im+g113,x15,x15]}],style:{'${symbolSelector}':{r:[_,_,x93,x94]}}},tt:{d:1137,a:y,data:[["eid439",zx,0,500,"linear",e111,'1','0.8'],["eid461",zx,500,500,"linear",e111,'0.8','1'],["eid435",zx,0,500,"linear",e95,'1','0.8'],["eid459",zx,500,500,"linear",e95,'0.8','1'],["eid436",zy,0,500,"linear",e95,'1','0.8'],["eid460",zy,500,500,"linear",e95,'0.8','1'],["eid441",zy,0,500,"linear",e111,'1','0.8'],["eid462",zy,500,500,"linear",e111,'0.8','1']]}}};AdobeEdge.registerCompositionDefn(compId,symbols,fonts,scripts,resources,opts);})("EDGE-56609439");
(function($,Edge,compId){var Composition=Edge.Composition,Symbol=Edge.Symbol;Edge.registerEventBinding(compId,function($){
//Edge symbol: 'stage'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",10042,function(sym,e){});
//Edge binding end
})("stage");
//Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'tandc'
(function(symbolName){Symbol.bindElementAction(compId,symbolName,"${open_click}","click",function(sym,e){sym.stop("closed");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${close_click}","click",function(sym,e){sym.stop("open");});
//Edge binding end
})("tandc");
//Edge symbol end:'tandc'

//=========================================================

//Edge symbol: 'Symbol_1'
(function(symbolName){})("Symbol_1");
//Edge symbol end:'Symbol_1'

//=========================================================

//Edge symbol: 'Symbol_3'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",7000,function(sym,e){sym.play();});
//Edge binding end
})("Symbol_3");
//Edge symbol end:'Symbol_3'

//=========================================================

//Edge symbol: 'tandc_1'
(function(symbolName){Symbol.bindElementAction(compId,symbolName,"${open_click}","click",function(sym,e){sym.stop("closed");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${close_click}","click",function(sym,e){sym.stop("open");});
//Edge binding end
})("tandc_1");
//Edge symbol end:'tandc_1'

//=========================================================

//Edge symbol: 'Symbol_3_1'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",1137,function(sym,e){sym.play();});
//Edge binding end
})("Symbol_3_1");
//Edge symbol end:'Symbol_3_1'

//=========================================================

//Edge symbol: 'Symbol_3_2'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",1137,function(sym,e){sym.play();});
//Edge binding end
})("Symbol_3_2");
//Edge symbol end:'Symbol_3_2'
})})(AdobeEdge.$,AdobeEdge,"EDGE-56609439");