FT.manifest({
	"filename":"fleet-a-970x250.html",
	"width":970,
	"height":250,
	"clickTagCount":1,
	"hideBrowsers":["ie8"]
});