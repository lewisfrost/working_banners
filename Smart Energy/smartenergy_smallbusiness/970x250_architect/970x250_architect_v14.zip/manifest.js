FT.manifest({
	"filename":"index.html",
	"width":970,
	"height":250,
	"clickTagCount":1,
	"hideBrowsers":["ie8"],
	"videos": [{"name": "video1", "ref": "55159/106284_SEBG_Architect_970x250_NoCopy_MotionJPEG-A"}],
	"instantAds":[
		{"name":"video1", "type": "video"}
	]
});