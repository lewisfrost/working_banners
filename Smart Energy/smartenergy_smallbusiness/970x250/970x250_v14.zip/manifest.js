FT.manifest({
	"filename":"index.html",
	"width":970,
	"height":250,
	"clickTagCount":1,
	"hideBrowsers":["ie8"],
	"videos": [{"name": "video1", "ref": "54965/105127_SEBG_Bride_970x250_v04"}],
	"instantAds":[
		{"name":"video1", "type": "video"}
	]
});