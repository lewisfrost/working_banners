FT.manifest({
	"filename":"index.html",
	"width":300,
	"height":600,
	"clickTagCount":1,
	"hideBrowsers":["ie8"],
	"videos": [{"name": "video1", "ref": "55159/106702_SEBG_Architect_300x213_NoCopy_MotionJPEG-A"}],
	"instantAds":[
		{"name":"video1", "type": "video"}
	]
});