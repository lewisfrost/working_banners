FT.manifest({
	"filename":"index.html",
	"width":300,
	"height":600,
	"clickTagCount":1,
	"hideBrowsers":["ie8"],
	"videos": [{"name": "video1", "ref": "54965/105112_SEBG_Bride_300x213_v2"}],
	"instantAds":[
		{"name":"video1", "type": "video"}
	]
});